import unittest
from textlib import BodyOfText

class TestBodyOfText(unittest.TestCase):
    def test_empty_story(self):
        pass

# Copyright 2015-2017 Aaron Maxwell. All rights reserved.
