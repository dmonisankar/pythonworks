class BodyOfText:
    def __init__(self, text):
        self.text = text
    def num_paragraphs(self):
        return -1
    def paragraphs(self):
        return []

# Copyright 2015-2017 Aaron Maxwell. All rights reserved.
