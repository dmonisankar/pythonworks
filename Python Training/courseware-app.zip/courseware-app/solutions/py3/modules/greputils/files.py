def grepfile():
    return 'Calling grepfile'

def grepfilei():
    return 'Calling grepfilei'

# Copyright 2015-2017 Aaron Maxwell. All rights reserved.
