from .html import (
    grep_html,
    grep_html_as_text,
    )
from .text import grep_text
from .json import grep_json

# Copyright 2015-2017 Aaron Maxwell. All rights reserved.
