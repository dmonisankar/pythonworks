def grep_json():
    return 'Calling grep_json'

# Copyright 2015-2017 Aaron Maxwell. All rights reserved.
