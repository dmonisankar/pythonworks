def contains():
    return 'Calling contains'

def containsi():
    return 'Calling containsi'

# Copyright 2015-2017 Aaron Maxwell. All rights reserved.
