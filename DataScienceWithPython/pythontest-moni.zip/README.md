# Python Hello World Sample

This application demonstrates a simple, reusable Python web application.

[![Deploy to Bluemix](https://bluemix.net/deploy/button.png)](https://bluemix.net/deploy?repository=https://github.com/IBM-Bluemix/python-helloworld)

## Run the app locally

1. [Install Python][]
+ cd into this project's root directory
+ Run `python server.py`
+ Access the running app in a browser at <http://localhost:8000>

[Install Python]: https://www.python.org/downloads/
